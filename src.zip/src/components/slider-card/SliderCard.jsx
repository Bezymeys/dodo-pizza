// import React from 'react';

// const Slidercard = () => {
//   // const ArraySliderCArd = [
//   //   {
//   //     img:"https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSdFqDhnfd2Xk2swLkJNbInqz0ptIDoAZ-KKQ&usqp=CAU",
//   //     title:"Новая модель"
//   //   },
//   //   {
//   //     img:"https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSdFqDhnfd2Xk2swLkJNbInqz0ptIDoAZ-KKQ&usqp=CAU",
//   //     title:"Новая модель"
//   //   },
//   //   {
//   //     img:"https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSdFqDhnfd2Xk2swLkJNbInqz0ptIDoAZ-KKQ&usqp=CAU",
//   //     title:"Новая модель"
//   //   },
//   //   {
//   //     img:"https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSdFqDhnfd2Xk2swLkJNbInqz0ptIDoAZ-KKQ&usqp=CAU",
//   //     title:"Новая модель"
//   //   },
//   // ]
//   return (
//     <div>
//         <img src={img} alt="" />  
//         <p>{title}</p>
//     </div>
//   )
// }

// export default Slidercard;
