export const baseUrl = "https://624eaf5e77abd9e37c89ae84.mockapi.io/";
export const pizzaApi = "pizza";
