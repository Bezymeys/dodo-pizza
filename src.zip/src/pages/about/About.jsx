import css from "./About.module.css";

export default function About() {
  return (
    <div>About</div>
  )
};
